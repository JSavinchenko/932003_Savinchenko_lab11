namespace W932003_Savinchenko_lab11.Models
{
   public class Actions
   {
       public int value1 { get; set; }
       public int value2 { get; set; }
       public int divide { get; set; }
       public int subtraction { get; set; }
       public int sum { get; set; }
       public int multiply { get; set; }
   }
}
